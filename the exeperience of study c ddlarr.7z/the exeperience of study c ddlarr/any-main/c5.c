//问题1：在屏幕上打印一个单引号'，怎么做？
//问题2：在屏幕上打印一个字符串，字符串的内容是一个双引号“，怎么做？

#include<stdio.h>
int main()
{
    printf("%c\n", '\'');
    printf("%s\n", "\"");
    return 0;
}