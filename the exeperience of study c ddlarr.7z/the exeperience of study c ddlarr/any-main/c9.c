#include<stdio.h>
int main(){
    int a = 0;
    printf("choose 1 or 2%d\n");
    scanf("%d",&a);
    if (a == 1);{
        printf("esxecrise\n");
    }
    
    else;
    
    {
        printf("exe");

    }
}