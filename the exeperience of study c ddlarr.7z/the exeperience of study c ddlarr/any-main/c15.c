#include<stdio.h>
int main(){
    int i = 0;
    int sum =0;
    do {
        sum = sum + i;
        i++;
    }while (i <= 100);
    printf("1~100:> %d", sum);/*do while的用法相较于while的区别为
    dowhile循环部分（循环体）会先检验一次，若条件为真则先循环一次，若为假则会终止循环
    那么do while 会至少执行一次循环 
    也就是while会执行0~n次 而 do while 会执行1~n次 */
    return 0;
}