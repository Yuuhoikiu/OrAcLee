#include<stdio.h>
/*----------------------------*/
int main()
{
    int num = 0;
    printf("input the num:>(0 or 1)");
    scanf("%d", &num);//一定要取num的值，否则为初始化的0值
    if (num == 1)
    {
        printf("you are right");
    }
    else
    {
        printf("you are wrong");
    }
    return 0;

}