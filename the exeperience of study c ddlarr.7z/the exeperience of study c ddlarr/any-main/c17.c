#include<stdio.h>
int prts();
int main(){
    int sum =0;
    int i = 0;
    while (i <=100)
    {
    sum = sum + i;
    i++;
    }
    printf("!~100 will output:> %d\n",sum);
    prts();
    return 0;
}
/*while循环实现1~100加和。*/

int prts(){
    int sum = 0;
    int i;
    for( i=1 ; i<=100 ; i++){
        sum = sum + i ;
    }
    printf("the answer of 1~100 IS:> %d\n", sum);
    return 0;
}
/*for循环实现1~100加和*/