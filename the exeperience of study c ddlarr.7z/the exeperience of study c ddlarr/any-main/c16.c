#include<stdio.h>

int prts();

int theresia();

int main(){
    int ch;
    printf("input any char:>");
    ch = getchar();
    printf("output char:>  %c\n", ch);
    while (getchar() !='\n');//清理输入缓冲区，避免prts函数跳过输入
    prts();//使用前需先声明
    theresia();
    return 0;
}
// getchar获取的字符为一个，输出也为一个。

int prts(){
    int zh;
    printf("input the sentence: \n ");
    while ((zh = getchar()) !='\n' && zh != EOF){
        putchar(zh);//对于一段字符的获取
    }
    printf("\n输出结束\n");
    return 0;
        
}

#include <stdio.h>
int theresia() {
    int age;
    char name[50];
    
    printf("请输入你的年龄：");
    scanf("%d", &age);
    
    // 清除输入缓冲区中的换行符
    while (getchar() != '\n');
    
    printf("请输入你的名字：");
    fgets(name, sizeof(name), stdin);//从指定的文件中读取一个字符串，并保存到字符数组中 原型fp,fp为文件指针。读取失败时返回 NULL；
    
    printf("你好，%s你的年龄是 %d 岁。\n", name, age);
    return 0;
} 