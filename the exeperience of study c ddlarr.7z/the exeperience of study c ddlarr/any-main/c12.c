#include<stdio.h>
enum choice
{
    DR = 0 , aMIYa , kaltist , theresia , prts , anyothere
};

int Prts = 3;

int main(){
    int ro =0;
    int num = 0;
    int sum = 0;
    int choice;
    printf("Which one you believe the num ber :> ");
    scanf("%d",&choice);
    if (choice == 4 )
    {
        printf("Stand by her side");
    } 
    else
    {
        printf("The Rhodes Island behind you");
    }
    return 0;
}