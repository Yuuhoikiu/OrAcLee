#include<stdio.h>
int yuu = 12;//全局参数
int main(){
    int yuu = 11;//局部参数
    printf("yuu的值为:> %d\n", yuu);
}
