#include<stdio.h>
int main(){
    int i = 0;
    int sum =0;
    while ( i <= 100)
    {
        sum +=i;
        i++;
        printf("1~100求和(while循环): %d\n", sum);
        /*return 0;
        如果在这里循环内部return o 这样循环会在结果为2的时候停止输出，即第一次循环后停止输出。*/
    }
    return 0;
    
}
