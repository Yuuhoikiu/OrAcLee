#include<stdio.h>
enum day
{
    mon =1 , tur , thr , tdr ,fri
};//枚举类型


int main(){
    printf("tur = %d\n",tur);
    return 0;//输出部分
}