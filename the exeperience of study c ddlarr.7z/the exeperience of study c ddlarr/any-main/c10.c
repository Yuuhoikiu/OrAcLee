#include<stdio.h>
enum day{
    as = 1 , aa , ad , af , ag , ar, at  //枚举类型
};
int main(){
    printf("ax的值为%d\n", ag);//输出部分
    return 0;
}