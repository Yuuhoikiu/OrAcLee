#include<stdio.h>

int main() {
    // 定义常量代替枚举值
    const int DR = 0;
    const int aMIYa = 1;
    const int kaltist = 2;
    const int theresia = 3;
    const int prts = 4;
    const int anyothere = 5;

    int choice;
    printf("Which one you believe (0-5):> ");
    scanf("%d", &choice);

    // 使用常量进行判定
    if (choice == prts) {
        printf("Stand by her side\n");
    } else if (choice >= DR && choice <= anyothere) {
        printf("The Rhodes Island behind you\n");
    } else {
        printf("Invalid choice!\n");
    }

    return 0;
}