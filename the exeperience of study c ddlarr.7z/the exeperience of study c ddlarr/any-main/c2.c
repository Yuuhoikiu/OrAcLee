#include<stdio.h>
int main(){
    int num = 0;
    int num1 = 0;
    int num2 = 0;
    int sum =0;
    //sum = num + num1 + num2;如果在这里计算则结果为0，因为结果被提前计算为0
    printf("input three num on here :>");
    scanf("%d" "%d" "%d" , &num,&num1,&num2);
    sum = num + num1 + num2;
    printf("sum = %d\n",sum);
    return 0;
}