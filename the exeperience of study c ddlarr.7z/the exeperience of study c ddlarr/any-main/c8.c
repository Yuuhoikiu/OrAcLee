#include<stdio.h>
int x = 1;
int y = 2;
int add(int x,int y){
    return x + y; 
}

int main(){
    printf("result %d\n",add(x,y));
}//add函数练习
