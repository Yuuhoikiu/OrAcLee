#include<stdio.h>

int prts();

int main() {
    int sum = 0;
    int i = 0;
    while (i <= 100) {
        sum = sum + i;
        i++;
    }
    printf("1~100 的总和为: %d\n", sum);
    prts();
    return 0;
}

int prts() {
    int sum = 0;
    int i;
    for (i = 1; i <= 100; i++) {
        sum = sum + i;
    }
    printf("1~100 的总和是: %d\n", sum);
    return 0;
}